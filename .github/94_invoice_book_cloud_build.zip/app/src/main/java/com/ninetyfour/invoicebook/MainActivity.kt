package com.ninetyfour.invoicebook

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val blue = Color.rgb(49, 73, 151)
    private lateinit var root: LinearLayout
    private lateinit var invoiceNo: EditText
    private lateinit var dateField: EditText
    private lateinit var customer: EditText
    private lateinit var vatRate: EditText
    private lateinit var widthField: EditText
    private lateinit var heightField: EditText
    private lateinit var paper: Spinner
    private lateinit var language: Spinner
    private val descriptions = mutableListOf<EditText>()
    private val quantities = mutableListOf<EditText>()
    private val rates = mutableListOf<EditText>()
    private var lastPdf: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun field(hint: String, value: String = ""): EditText {
        return EditText(this).apply {
            this.hint = hint; setText(value); textSize = 14f
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), 0xFFD5DCEB.toInt()); cornerRadius = dp(7).toFloat()
            }
        }
    }
    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 13f; setTextColor(0xFF263653.toInt())
    }
    private fun addFieldRow(parent: LinearLayout, title: String, edit: EditText) {
        parent.addView(label(title))
        parent.addView(edit, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(9) })
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(blue)
        setOnClickListener { action() }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF3F5FA.toInt()) }
        val header = TextView(this).apply {
            text = "94 INVOICE BOOK"; textSize = 23f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16)); setBackgroundColor(blue); typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(22)) }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val bilingual = TextView(this).apply {
            text = "Create paper-style tax invoices • فاتورة ضريبية"; textSize = 13f; setTextColor(0xFF58647A.toInt())
        }
        body.addView(bilingual)
        body.addView(label("Invoice details / تفاصيل الفاتورة"))
        invoiceNo = field("Invoice number", "31")
        dateField = field("Date", SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
        customer = field("Customer name / اسم العميل")
        addFieldRow(body, "Invoice No. / رقم الفاتورة", invoiceNo)
        addFieldRow(body, "Date / التاريخ", dateField)
        addFieldRow(body, "Customer / العميل (optional)", customer)

        body.addView(label("Paper size / حجم الورق"))
        paper = Spinner(this)
        val paperItems = listOf("80 mm roll", "58 mm roll", "A4", "Custom")
        paper.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, paperItems)
        body.addView(paper, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        val dimensions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        widthField = field("Width mm", "80"); heightField = field("Height mm", "200")
        dimensions.addView(widthField, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) })
        dimensions.addView(heightField, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(6) })
        body.addView(dimensions)
        paper.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                when(position) { 0 -> { widthField.setText("80"); heightField.setText("200") }; 1 -> { widthField.setText("58"); heightField.setText("200") }; 2 -> { widthField.setText("210"); heightField.setText("297") } }
            }
        }
        body.addView(label("Language / اللغة"))
        language = Spinner(this)
        language.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("English + Arabic", "English only", "Arabic only"))
        body.addView(language, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        vatRate = field("VAT %", "5")
        addFieldRow(body, "VAT rate / نسبة الضريبة", vatRate)

        body.addView(label("Items / الأصناف (13 rows)"))
        val tableHeader = TextView(this).apply {
            text = "DESCRIPTION / البيان                 QTY       RATE"; textSize = 12f
            setTextColor(Color.WHITE); setPadding(dp(8), dp(9), dp(8), dp(9)); setBackgroundColor(blue)
        }
        body.addView(tableHeader)
        repeat(13) { i ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val desc = field("Item ${i+1} / الوصف")
            val qty = field("Qty", "")
            val rate = field("Rate", "")
            row.addView(desc, LinearLayout.LayoutParams(0, dp(44), 5f).apply { marginEnd = dp(3); topMargin = dp(4) })
            row.addView(qty, LinearLayout.LayoutParams(0, dp(44), 1.3f).apply { setMargins(dp(3), dp(4), dp(3), 0); topMargin = dp(4) })
            row.addView(rate, LinearLayout.LayoutParams(0, dp(44), 2f).apply { marginStart = dp(3); topMargin = dp(4) })
            body.addView(row); descriptions.add(desc); quantities.add(qty); rates.add(rate)
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(14), 0, 0) }
        actions.addView(button("PREVIEW & SAVE PDF / معاينة وحفظ PDF") { createPdf() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(8) })
        actions.addView(button("PRINT / طباعة") { createPdf(); lastPdf?.let { openPdf(it) } },
            LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(8) })
        actions.addView(button("SHARE PDF / مشاركة") { createPdf(); lastPdf?.let { sharePdf(it) } },
            LinearLayout.LayoutParams(-1, dp(52)))
        body.addView(actions)
        setContentView(root)
    }

    private fun num(e: EditText): Double = e.text.toString().trim().toDoubleOrNull() ?: 0.0
    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)

    private fun createPdf() {
        try {
            val wmm = widthField.text.toString().toFloatOrNull()?.coerceIn(40f, 500f) ?: 80f
            val hmm = heightField.text.toString().toFloatOrNull()?.coerceIn(80f, 1000f) ?: 200f
            val width = (wmm * 72f / 25.4f).roundToInt().coerceAtLeast(120)
            val height = (hmm * 72f / 25.4f).roundToInt().coerceAtLeast(220)
            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, 1).create())
            val c = page.canvas
            c.drawColor(Color.WHITE)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = blue; style = Paint.Style.STROKE; strokeWidth = 0.65f }
            val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = blue; textSize = if(wmm < 65) 6f else 7.5f; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
            val bold = Paint(t).apply { typeface = Typeface.create("sans-serif", Typeface.BOLD) }
            val margin = 9f
            val usable = width - margin * 2
            var y = 15f
            fun txt(s: String, x: Float, yy: Float, paint: Paint = t) { c.drawText(s, x, yy, paint) }
            fun line(x1: Float, y1: Float, x2: Float, y2: Float) { c.drawLine(x1,y1,x2,y2,p) }
            txt("TAX INVOICE", margin, y + 7, bold); txt("فاتورة ضريبية", width * .57f, y + 7, bold)
            y += 15
            txt("Inv. No. ${invoiceNo.text}", margin, y); txt("Date: ${dateField.text}", width * .52f, y)
            y += 12
            txt("Customer: ${customer.text}", margin, y); y += 14
            val cols = floatArrayOf(margin, margin+18, margin+usable*.57f, margin+usable*.69f, margin+usable*.82f, width-margin)
            val headerH = 19f
            line(margin,y,width-margin,y); line(margin,y+headerH,width-margin,y+headerH)
            for(x in cols) line(x,y,x,y+headerH+13*19+25)
            val labels = listOf("S.No","DESCRIPTION","QTY","RATE","VAT","AMOUNT")
            for(i in labels.indices) txt(labels[i], cols[i]+2, y+12, bold)
            y += headerH
            var subtotal = 0.0
            val vr = (vatRate.text.toString().toDoubleOrNull() ?: 5.0) / 100.0
            for(i in 0 until 13) {
                val q = num(quantities[i]); val r = num(rates[i]); val base = q*r; val tax = base*vr
                subtotal += base
                txt("${i+1}", cols[0]+3, y+12)
                val desc = descriptions[i].text.toString()
                txt(desc.take(23), cols[1]+2, y+12)
                txt(if(q==0.0) "" else money(q), cols[2]+2, y+12)
                txt(if(r==0.0) "" else money(r), cols[3]+2, y+12)
                txt(if(base==0.0) "" else money(tax), cols[4]+2, y+12)
                txt(if(base==0.0) "" else money(base+tax), cols[5]-34, y+12)
                y += 19
                line(margin,y,width-margin,y)
            }
            y += 13
            txt("Subtotal / المجموع الفرعي: ${money(subtotal)}", margin, y, bold); y += 12
            txt("VAT ${money(vr*100)}% / ضريبة القيمة المضافة: ${money(subtotal*vr)}", margin, y, bold); y += 13
            line(margin,y,width-margin,y); y += 13
            txt("TOTAL / الإجمالي: ${money(subtotal*(1+vr))}", margin, y, bold)
            y += 18
            txt("E.&O.E.", margin, y); y += 22
            line(margin,y, width*.43f,y); line(width*.58f,y,width-margin,y)
            txt("Rec. Signature", margin, y+10); txt("Signature / التوقيع", width*.58f, y+10)
            doc.finishPage(page)
            val dir = File(getExternalFilesDir(null), "Invoices").apply { mkdirs() }
            val file = File(dir, "Invoice_${invoiceNo.text}_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }; doc.close()
            lastPdf = file
            Toast.makeText(this, "PDF saved: ${file.name}", Toast.LENGTH_LONG).show()
            openPdf(file)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not create PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun openPdf(file: File) {
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        try { startActivity(Intent.createChooser(intent, "Open / Print invoice")) }
        catch (_: Exception) { Toast.makeText(this, "Install a PDF viewer or printer app", Toast.LENGTH_LONG).show() }
    }
    private fun sharePdf(file: File) {
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "Share invoice PDF"))
    }
}
