# 94 INVOICE BOOK — Android project

A starter Android application project for bilingual (English/Arabic) invoice creation with a paper-style tax invoice PDF layout.

## Features in this build
- Android app project (min Android 6.0 / API 23)
- English + Arabic labels
- 13 invoice item rows
- Quantity, rate, VAT and automatic totals
- 80 mm, 58 mm, A4 and custom PDF page dimensions
- Save PDF to app external-files `Invoices` folder
- Open PDF in a viewer / Android print service, or share PDF

## Build APK
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The APK will be under `app/build/outputs/apk/debug/`.

## Printing note
The app generates a PDF sized to the selected paper dimensions and invokes an installed PDF viewer. For Bluetooth thermal printers, install a compatible Android print service / printer app for your printer model, then choose it from the Android print dialog. Bluetooth printer compatibility varies by model.

## Important limitations of this starter version
- This is a source project, not a compiled APK.
- Invoice history/database, editable company profile, invoice numbering automation, and direct model-specific ESC/POS Bluetooth printing are not implemented yet.
- Arabic text is included in labels; full RTL table shaping and Arabic glyph rendering should be verified on-device before production use.
- VAT default is 5%; confirm your tax setup before issuing official invoices.
