# 94 Invoice Note V2

A fresh Android Studio project for an editable English invoice note.

Included in this starter:
- Editable company, sender, customer, invoice number, date, terms and order reference
- Add invoice item rows (quantity, description, rate)
- Automatic subtotal, VAT and total calculation
- Print / Save as PDF through Android's print dialog
- Paper presets: A4, 80mm and 58mm
- Java 17 and Kotlin JVM 17 configuration

## Build APK
Open this folder in Android Studio, allow Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s)

APK output: `app/build/outputs/apk/debug/app-debug.apk`

Printer compatibility depends on Android print services installed on the phone. This is a starter V2 build; persistent invoice history, full custom dimensions, branding controls and dedicated Bluetooth printer integration are not included yet.
