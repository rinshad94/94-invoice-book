package com.ninetyfour.invoicenote

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Gravity
import android.widget.*
import android.text.InputType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var company: EditText
    private lateinit var from: EditText
    private lateinit var to: EditText
    private lateinit var invoiceNo: EditText
    private lateinit var date: EditText
    private lateinit var terms: EditText
    private lateinit var orderRef: EditText
    private lateinit var vatNo: EditText
    private lateinit var vatRate: EditText
    private lateinit var rowsBox: LinearLayout
    private lateinit var subtotalText: TextView
    private lateinit var vatText: TextView
    private lateinit var totalText: TextView
    private val itemRows = mutableListOf<ItemRow>()
    private var paper = "A4"
    private var currency = "AED"

    data class ItemRow(val qty: EditText, val description: EditText, val rate: EditText)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showInvoice()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun edit(hintText: String, numeric: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            textSize = 14f
            setSingleLine(false)
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setBackgroundColor(Color.WHITE)
        }

    private fun label(value: String, size: Float = 14f) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(Color.rgb(38, 76, 105))
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        setOnClickListener { action() }
    }

    private fun field(title: String, value: EditText) {
        root.addView(label(title))
        root.addView(value, LinearLayout.LayoutParams(-1, dp(48)))
    }

    private fun showInvoice() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
            setBackgroundColor(Color.rgb(242, 247, 249))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("94 INVOICE NOTE", 24f))
        root.addView(label("Editable invoice • English", 13f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("Settings") { showSettings() }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button("Print / PDF") { printInvoice() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)

        company = edit("Company name / address")
        from = edit("From")
        to = edit("Customer / To")
        invoiceNo = edit("Invoice number").apply { setText("94-0001") }
        date = edit("Date").apply { setText(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())) }
        terms = edit("Terms")
        orderRef = edit("Order reference")
        vatNo = edit("VAT number")
        vatRate = edit("VAT %").apply { setText("5") }

        field("Company", company)
        field("From", from)
        field("To", to)
        field("Invoice No.", invoiceNo)
        field("Date", date)
        val info = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        info.addView(terms, LinearLayout.LayoutParams(0, dp(48), 1f))
        info.addView(orderRef, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(info)
        field("VAT No.", vatNo)
        field("VAT rate (%)", vatRate)

        root.addView(label("ITEMS", 18f))
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Qty", "Description", "Rate").forEach { title ->
            header.addView(TextView(this@MainActivity).apply {
                text = title
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(45, 130, 144))
                setPadding(4, dp(8), 4, dp(8))
            }, LinearLayout.LayoutParams(0, -2, if (title == "Description") 3f else 1f))
        }
        root.addView(header)
        rowsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(rowsBox)
        repeat(5) { addItemRow() }
        root.addView(button("+ Add item") { addItemRow() })

        subtotalText = label("Subtotal: $currency 0.00", 16f)
        vatText = label("VAT: $currency 0.00", 16f)
        totalText = label("TOTAL: $currency 0.00", 20f)
        root.addView(subtotalText)
        root.addView(vatText)
        root.addView(totalText)
        root.addView(label("E. & O.E.", 13f))
        root.addView(label("Received by: __________________       Signature: __________________"))
        root.addView(button("Update totals") { updateTotals() })
        updateTotals()
    }

    private fun addItemRow() {
        val q = edit("1", true).apply { setText("1") }
        val d = edit("Description")
        val r = edit("0.00", true)
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        line.addView(q, LinearLayout.LayoutParams(0, dp(52), 1f))
        line.addView(d, LinearLayout.LayoutParams(0, dp(52), 3f))
        line.addView(r, LinearLayout.LayoutParams(0, dp(52), 1f))
        rowsBox.addView(line)
        itemRows.add(ItemRow(q, d, r))
    }

    private fun num(v: EditText): Double = v.text.toString().toDoubleOrNull() ?: 0.0
    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)

    private fun updateTotals() {
        val sub = itemRows.sumOf { num(it.qty) * num(it.rate) }
        val rate = num(vatRate)
        val tax = sub * rate / 100.0
        subtotalText.text = "Subtotal: $currency ${money(sub)}"
        vatText.text = "VAT (${money(rate)}%): $currency ${money(tax)}"
        totalText.text = "TOTAL: $currency ${money(sub + tax)}"
    }

    private fun showSettings() {
        val names = arrayOf("A4", "80mm Roll", "58mm Roll", "Custom")
        AlertDialog.Builder(this).setTitle("Print settings").setItems(names) { _, which ->
            paper = names[which]
            Toast.makeText(this, "Paper: $paper", Toast.LENGTH_SHORT).show()
        }.setNeutralButton("Currency") { _, _ ->
            val input = EditText(this).apply { setText(currency); hint = "Currency code" }
            AlertDialog.Builder(this).setTitle("Currency code").setView(input)
                .setPositiveButton("Save") { _, _ ->
                    currency = input.text.toString().ifBlank { "AED" }
                    updateTotals()
                }.setNegativeButton("Cancel", null).show()
        }.setNegativeButton("Close", null).show()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;")

    private fun invoiceHtml(): String {
        val sub = itemRows.sumOf { num(it.qty) * num(it.rate) }
        val tax = sub * num(vatRate) / 100.0
        val rows = itemRows.filter { it.description.text.isNotBlank() || num(it.rate) != 0.0 }
            .joinToString("") {
                "<tr><td>${esc(it.qty.text.toString())}</td><td>${esc(it.description.text.toString())}</td>" +
                "<td>${money(num(it.rate))}</td><td>${money(num(it.qty) * num(it.rate))}</td></tr>"
            }
        val width = when {
            paper.startsWith("80") -> "72mm"
            paper.startsWith("58") -> "50mm"
            else -> "190mm"
        }
        return """
        <html><head><meta name="viewport" content="width=device-width, initial-scale=1"><style>
        @page { size: auto; margin: 8mm; }
        *{box-sizing:border-box} body{font-family:Arial,sans-serif;color:#244b68;margin:0 auto;width:$width;font-size:12px}
        h2{color:#287f91;margin:0 0 12px;border-bottom:1px dotted #6c9eaa;padding-bottom:8px}
        .box{border:1px solid #6c9eaa;padding:7px;margin:7px 0}
        table{width:100%;border-collapse:collapse;table-layout:fixed;margin-top:12px}
        th,td{border:1px solid #5b8794;padding:7px 4px;overflow-wrap:anywhere;text-align:left}
        th{background:#edf5f7} .totals{margin-left:auto;width:75%;text-align:right;line-height:1.9}
        .grand{font-size:16px;font-weight:bold;border-top:2px solid #287f91;padding-top:5px}
        .sign{display:flex;justify-content:space-between;margin-top:35px}
        </style></head><body>
        <h2>INVOICE <span style="float:right;font-size:12px">No. ${esc(invoiceNo.text.toString())}</span></h2>
        <div class="box"><b>${esc(company.text.toString())}</b><br><b>From:</b> ${esc(from.text.toString())}<br><b>To:</b> ${esc(to.text.toString())}</div>
        <div class="box">Date: ${esc(date.text.toString())}<br>Terms: ${esc(terms.text.toString())}<br>Order Ref: ${esc(orderRef.text.toString())}</div>
        <table><thead><tr><th>Qty</th><th>Description</th><th>Rate</th><th>Amount</th></tr></thead><tbody>$rows</tbody></table>
        <div class="box">VAT No.: ${esc(vatNo.text.toString())}</div>
        <div class="totals">Subtotal: $currency ${money(sub)}<br>VAT (${money(num(vatRate))}%): $currency ${money(tax)}
        <div class="grand">TOTAL: $currency ${money(sub + tax)}</div></div>
        <p>E. &amp; O.E.</p><div class="sign"><span>Received by: __________</span><span>Signature: __________</span></div>
        </body></html>
        """.trimIndent()
    }

    private fun printInvoice() {
        updateTotals()
        val web = WebView(this)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                manager.print("94 Invoice Note", view.createPrintDocumentAdapter("94-Invoice-${invoiceNo.text}"),
                    PrintAttributes.Builder().build())
            }
        }
        web.loadDataWithBaseURL(null, invoiceHtml(), "text/HTML", "UTF-8", null)
    }
}
